<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
	$cname = $_POST['name'];
	$bday = $_POST['bday'];
	$class = $_POST['class'];
   
    // if(isset($_FILES['imageToUpload'])){
    //     move_uploaded_file($_FILES['imageToUpload']['tmp_name'], "images/". $_FILES['imageToUpload']['name']);
    //   }
    //   else{
    //       echo "image not found!";
    //   }
// ob_start();
// session_start();
// define('DB_HOST','localhost');
// define('DB_USER','root');
// define('DB_PASS','');
// define('DB_NAME','inv');
// function connect(){
//     $connect=mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
//     return $connect;
// }
// $con = connect();
require("TCPDF/tcpdf.php");
$pdf = new TCPDF(PDF_PAGE_ORIENTATION,PDF_UNIT,PDF_PAGE_FORMAT,true,'UTF-8',false);
$pdf->setPrintHeader(false);
$pdf->setPrintFooter(false);
$pdf->AddPage();
$pdf->setFont('helvetica','B',12 );
// $pdf->Cell(0, 0, $cname, 1, 1, 'C', 0, '', 2);
$tbl = <<<EOD
<table border="1" cellpadding="2" cellspacing="2" align="center">
 <tr nobr="true">
  <th colspan="3">$cname</th>
 </tr>
 <tr nobr="true">
  <td>$cname</td>
  <td>ROW 1<br />COLUMN 2</td>
  <td>ROW 1<br />COLUMN 3</td>
 </tr>
 <tr nobr="true">
  <td>ROW 2<br />COLUMN 1</td>
  <td>ROW 2<br />COLUMN 2</td>
  <td>ROW 2<br />COLUMN 3</td>
 </tr>
 <tr nobr="true">
  <td>ROW 3<br />COLUMN 1</td>
  <td>ROW 3<br />COLUMN 2</td>
  <td>ROW 3<br />COLUMN 3</td>
 </tr>
</table>
EOD;

$pdf->writeHTML($tbl, true, false, false, false, '');
$tbl = <<<EOD
<table border="1" cellpadding="2" cellspacing="2" nobr="true">
 <tr>
  <th colspan="3" >$cname</th>
 </tr>
 <tr>
  <td colspan="3" >$cname</td>
 
 </tr>
 <tr>
  <td>2-1</td>
  <td>3-2</td>
  <td>3-3</td>
 </tr>
 <tr>
  <td>3-1</td>
  <td>3-2</td>
  <td>3-3</td>
 </tr>
</table>
EOD;

$pdf->writeHTML($tbl, true, false, false, false, '');
$tbl = <<<EOD
<table border="1" cellpadding="2" cellspacing="2">
<thead>
 <tr >
  <td width="30" align="center"><b>Q.1</b></td>
  <td colspan="10"  >$cname <br /><img src="images/ss.jpg" height="200" width="200"></td>
  
  <td colspan="1" align="center"><b>5</b></td>
 </tr>
 <tr style="background-color:#FF0000;color:#FFFF00;">
  <td width="30" align="center"><b>B</b></td>
  <td width="140" align="center"><b>XXXX</b></td>
  <td width="140" align="center"><b>XXXX</b></td>
  <td width="80" align="center"> <b>XXXX</b></td>
  <td width="80" align="center"><b>XXXX</b></td>
  <td width="45" align="center"><b>XXXX</b></td>
 </tr>
</thead>
 <tr>
  <td width="30" align="center">1.</td>
  <td width="140" rowspan="6">XXXX<br />XXXX<br /></td>
  <td width="140">XXXX<br />XXXX</td>
  <td width="80">XXXX<br />XXXX</td>
  <td width="80">XXXX</td>
  <td align="center" width="45">XXXX<br />XXXX</td>
 </tr>
 
</table>
EOD;

$pdf->writeHTML($tbl, true, false, false, false, '');

$pdf->Output('example.pdf','I');


}

?>





<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>HOME</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.0/font/bootstrap-icons.css">
</head>
<body>
	 <div class="d-flex justify-content-center align-items-center flex-column" style="min-height: 100vh;">
	 	<i class="bi bi-person-fill" style="font-size: 14rem"></i>
        
        <form method="post">
	<input type="textbox" name="name"/>
	<input type="textbox" name="class" placeholder = "class"/>
	<input type="date" name="bday" required pattern="\d{4}-\d{2}-\d{2}" />
    <input type="file" name="imageToUpload">
	<input type="submit"/>
</form>

	 </div>
</body>
</html>
